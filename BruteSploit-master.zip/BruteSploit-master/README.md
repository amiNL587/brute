# Brutesploit

[![Version](https://img.shields.io/badge/Brutesploit-1.1.0-brightgreen.svg?maxAge=259200)]()
[![Version](https://img.shields.io/badge/Codename-Pretty-red.svg?maxAge=259200)]()
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Linux-orange.svg)]()

BruteSploit is a collection of method for automated Generate, Bruteforce and Manipulation wordlist with interactive shell.
That can be used during a penetration test to enumerate and can be used in CTF for manipulation,combine,transform and permutation some words or file text :p i wrote this just for fun and learn how create interactive shell  is work



<img src="https://cloud.githubusercontent.com/assets/17976841/26713523/583b95aa-4797-11e7-93a5-d67a66726e5c.png" ></img> 


### Donate
- If this project very help you to penetration testing  and u want support me , you can give me a cup of coffee :)
- [![Donation](https://img.shields.io/badge/bitcoin-donate-yellow.svg)](https://blockchain.info/id/address/1NuNTXo7Aato7XguFkvwYnTAFV2immXmjS)



### Features & Tutorial [ Request submit a new issue ]
- https://www.youtube.com/watch?v=x51As2OS2z4 
- Channel : https://www.youtube.com/screetsec

Check in this video : 

## :scroll: Changelog
Be sure to check out the [Changelog] and Read CHANGELOG.md


## Getting Started
1. ```git clone https://github.com/Screetsec/Brutesploit.git```
2. ```cd Brutesploit```
3. ```chmod +x Brutesploit ```
3. ```sudo ./Brutesploit or sudo su ./Brutesploit ```

 

## A linux operating system. We recommend :
- Kali Linux 2 or Kali 2016.1 rolling 
- Cyborg
- Parrot 
- BackTrack 
- Backbox  


## BUG ? 
- Please Submit new issue 
- Contact me
- Hey sup ? do you want ask about all my tools ? you can join me in telegram.me/offscreetsec

## Donations 

- Donation: Send to [bitcoin](https://blockchain.info/id/address/1NuNTXo7Aato7XguFkvwYnTAFV2immXmjS)

- Addres Bitcoin : 1NuNTXo7Aato7XguFkvwYnTAFV2immXmjS

- <img src="https://cloud.githubusercontent.com/assets/17976841/25007109/75380fa6-2089-11e7-8a4a-4a8ae9c06e24.png" width="30%"></img>

## :octocat: Credits

- Thanks to allah and Screetsec [ Edo -maland- ] <Me> 
- Dracos Linux ( www.dracos-linux.org )  
- Backbox indonesia ( www.www.backboxindonesia.or.id )  
- Offensive Security for the awesome OS
- Kali Linux ( http://www.kali.org/ )  
- http://www.kitploit.com/
- Big Thanks to : http://www.github.com/ 





## Disclaimer

***Note: modifications, changes, or alterations to this sourcecode is acceptable, however,any public releases utilizing this code must be approved by writen this tool ( Edo -m- ).***
