#Grep from kaskus
