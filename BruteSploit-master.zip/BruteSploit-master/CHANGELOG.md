
- v.1.1.1 Added Brute Instagram
- v.1.1.0 Fixed Bugs 
- v.1.0.0 Release Brutsploit
